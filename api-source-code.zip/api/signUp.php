<?php
require_once "connectDB.php";

$email = $_POST['email'];
$password = $_POST['password'];
$name = $_POST['name'];

$query = "SELECT * FROM user WHERE email = '$email'";
if ($data = mysqli_query($connect, $query)) {
    if (empty(mysqli_fetch_assoc($data))) {
        $query = "INSERT INTO user VALUES(null, '$name', null, null, '$email', '$password')";
        if (mysqli_query($connect, $query)) {
            $query = "SELECT * FROM user WHERE email = '$email' AND password = '$password' LIMIT 1";
            $data = mysqli_query($connect, $query);
            if ($data && !empty($user = mysqli_fetch_assoc($data))) {
            	echo json_encode($user);
            } else{
                http_response_code(500);
            	echo 'An error occurred' .$connect->error;
            }
        } else{
            http_response_code(500);
        	echo 'An error occurred' .$connect->error;
        }
    } else {
        http_response_code(400);
        echo 'Email has already existed';
    }
} else {
    http_response_code(500);
	echo 'An error occurred' .$connect->error;
}
?>