<?php
$connect = mysqli_connect("localhost","id14985528_ducthinh1","Ducthinhtrai_1","id14985528_bestbus");
mysqli_query($connect, "SET NAMES 'utf8'");
header('Content-type: application/json');
?>